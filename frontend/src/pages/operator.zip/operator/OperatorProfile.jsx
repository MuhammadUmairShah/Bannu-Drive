import { useState } from 'react';
import { User } from 'lucide-react';
import api from '../../utils/api';
import { getErrorMessage } from '../../utils/errors';
import { toast } from '../../utils/toast';
import { useAuth } from '../../context/AuthContext';
import ProfilePicture from '../../components/ProfilePicture';
import ChangePasswordForm from '../../components/ChangePasswordForm';
import VerificationPanel from '../../components/verification/VerificationPanel';
import { PageHeader, Badge, Field, inputCls, btnPrimary } from '../../components/ui';

export default function OperatorProfile() {
  const { user, setUser } = useAuth();
  const [company, setCompany] = useState({ companyName: user?.operator?.companyName || '', contactPhone: user?.operator?.contactPhone || '' });
  const [saving, setSaving] = useState(false);

  async function save(e) {
    e.preventDefault();
    try {
      setSaving(true);
      const r = await api.patch('/coach/operator/me', company);
      if (r.data.success) { setUser((u) => ({ ...u, operator: r.data.operator })); toast.success('Company profile updated'); } else toast.error(r.data.message);
    } catch (err) { toast.error(getErrorMessage(err)); } finally { setSaving(false); }
  }

  return (
    <div className="max-w-2xl space-y-5">
      <PageHeader icon={User} title="Profile" subtitle="Your operator account" />
      <div className="card p-5 space-y-4">
        <ProfilePicture />
        <div className="text-xs text-muted space-y-1"><p><b>{user?.name}</b> • {user?.email} • {user?.phone}</p>
          <p>Status: {user?.isVerified ? <Badge tone="green">approved</Badge> : <Badge tone="amber">waiting for approval</Badge>}</p></div>
      </div>
      <VerificationPanel />
      <form onSubmit={save} className="card p-5 grid gap-3 sm:grid-cols-2 items-end">
        <Field label="Company name"><input required minLength={2} maxLength={80} className={inputCls} value={company.companyName} onChange={(e) => setCompany({ ...company, companyName: e.target.value })} /></Field>
        <Field label="Contact phone"><input className={inputCls} maxLength={20} value={company.contactPhone} onChange={(e) => setCompany({ ...company, contactPhone: e.target.value })} /></Field>
        <div><button className={btnPrimary} disabled={saving || !user?.isVerified}>{saving ? 'Saving...' : 'Save company details'}</button></div>
      </form>
      <div className="card p-5"><ChangePasswordForm /></div>
    </div>
  );
}
